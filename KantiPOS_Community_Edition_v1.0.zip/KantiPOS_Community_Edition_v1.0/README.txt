Before you can can be able to use this software, you must do following, if you already have not:
1. Install .NET Framework 3.5 or Above
2. Default system administrator's password is blank and code is "1001". But it is always recommended to change this later on.